This folder contains exercise files to create a custom map using the Simulation Map Generator App

exercises - Files for exercise and practice tasks
[~] GeneratingCustomMap_Exercise.pdf : Introduces the exercise tasks and presents respective solutions
[~] imageForSimMap.jpg : Image file of the custom path's image
[~] exampleSimMap.mat : Solution MAT file containing the custom path's map data

Copyright 2017 The MathWorks, Inc.